CREATE DATABASE IF NOT EXISTS royal_grand_hotel;
USE royal_grand_hotel;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(180) NOT NULL UNIQUE,
  phone VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('customer','admin') DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS rooms (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  category VARCHAR(80) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  capacity INT NOT NULL DEFAULT 2,
  size_sqm INT DEFAULT 30,
  image_url TEXT,
  amenities TEXT,
  active BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  booking_code VARCHAR(32) NOT NULL UNIQUE,
  user_id INT NOT NULL,
  room_id INT NOT NULL,
  check_in DATE NOT NULL,
  check_out DATE NOT NULL,
  guests INT NOT NULL DEFAULT 1,
  nights INT NOT NULL,
  total_amount DECIMAL(10,2) NOT NULL,
  status ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
  payment_status ENUM('unpaid','paid','refunded') DEFAULT 'unpaid',
  razorpay_order_id VARCHAR(120),
  razorpay_payment_id VARCHAR(120),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (room_id) REFERENCES rooms(id)
);

CREATE TABLE IF NOT EXISTS menu_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  category VARCHAR(80) NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  image_url TEXT,
  is_veg BOOLEAN DEFAULT TRUE,
  available BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS table_reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  email VARCHAR(180),
  phone VARCHAR(20) NOT NULL,
  reservation_date DATE NOT NULL,
  reservation_time TIME NOT NULL,
  guests INT NOT NULL,
  notes TEXT,
  status ENUM('pending','confirmed','cancelled') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reviews (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_name VARCHAR(120) NOT NULL,
  rating INT NOT NULL,
  comment TEXT NOT NULL,
  approved BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO rooms (name,category,description,price,capacity,size_sqm,image_url,amenities) VALUES
('Deluxe King Room','Deluxe','A beautifully appointed room with king bed and city views.',4999,2,32,'https://images.unsplash.com/photo-1611892440504-42a792e24d32?w=1000','King bed, Wi-Fi, Smart TV, Air conditioning'),
('Premium Executive Room','Premium','A spacious retreat with refined interiors and premium amenities.',6999,2,42,'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=1000','King bed, Work desk, Wi-Fi, Mini bar'),
('Royal Family Suite','Suite','An expansive suite designed for memorable family stays.',9999,4,68,'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=1000','Two beds, Living area, Bathtub, Wi-Fi');

INSERT INTO menu_items (name,category,description,price,image_url,is_veg) VALUES
('Paneer Tikka','Starters','Char-grilled cottage cheese with aromatic spices.',349,'https://images.unsplash.com/photo-1567188040759-fb8a883dc6d8?w=800',TRUE),
('Royal Veg Biryani','Main Course','Fragrant basmati rice layered with garden vegetables.',429,'https://images.unsplash.com/photo-1563379091339-03246963d96a?w=800',TRUE),
('Chocolate Fondant','Desserts','Warm chocolate cake with a molten centre.',299,'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=800',TRUE);
