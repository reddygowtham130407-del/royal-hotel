# Royal Grand Hotel — Full-stack starter project

A luxury black-and-gold hotel + restaurant booking website using HTML/CSS/JavaScript, Node.js/Express and MySQL.

## Included
- Responsive premium hotel homepage
- Rooms and suites listing from MySQL
- Customer registration and login
- Room booking with date overlap checks
- Razorpay order creation and server-side signature verification
- Restaurant menu and table reservation requests
- Admin dashboard, booking status controls, room creation
- MySQL schema and demo room/menu seed data

## Requirements
- Node.js 18+
- MySQL 8+
- Razorpay account for online payments (use test keys first)

## Setup
1. Create the database and tables:
   `mysql -u root -p < database/schema.sql`
2. Install dependencies:
   `npm install`
3. Copy `.env.example` to `.env` and enter MySQL credentials and a long random SESSION_SECRET.
4. Create an admin user:
   `node scripts/create-admin.js`
5. Add Razorpay test credentials to `.env`.
6. Start:
   `npm start`
7. Open `http://localhost:3000`.

## Important before production
- This is a functional starter, not a finished audited hospitality product.
- Configure HTTPS and secure cookies behind your production proxy.
- Replace express-session's in-memory store with a persistent session store.
- Add CSRF protection, rate limiting, input sanitization, audit logs, backups and monitoring.
- Add email/WhatsApp notifications and refund workflow if required.
- Configure Razorpay webhooks and reconcile payment events. Never rely only on a browser callback.
- Review booking expiry rules: pending unpaid reservations currently remain blocking until cancelled/expired manually. Add an expiry job before launch.
- Add tax/fee calculation and clearly disclose cancellation/refund policies.
- Restrict admin account creation and use strong passwords.
- Replace demo brand, address, phone, email, images, prices, policies and facility claims with verified hotel details.
- Verify room inventory model if the hotel has multiple units per room category. Current demo treats each room record as one bookable unit.
- Use actual licensed images and confirm all displayed amenities are available.

## Main API routes
- `GET /api/rooms`, `GET /api/menu`, `GET /api/me`
- `POST /api/register`, `POST /api/login`, `POST /api/logout`
- `POST /api/bookings`, `GET /api/my-bookings`
- `POST /api/payments/order`, `POST /api/payments/verify`
- `POST /api/table-reservations`, `POST /api/reviews`, `GET /api/reviews`
- Admin: `GET /api/admin/summary`, `GET /api/admin/bookings`, `PATCH /api/admin/bookings/:id`, `POST /api/admin/rooms`

## Demo content
The seeded rooms, menu items, hotel address and contact details are placeholders. Replace them before showing this to a real customer.
