require("dotenv").config();
const express = require("express");
const cors = require("cors");
const session = require("express-session");
const mysql = require("mysql2/promise");
const bcrypt = require("bcryptjs");
const Razorpay = require("razorpay");
const crypto = require("crypto");
const path = require("path");

const app = express();
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-this-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false }
}));
app.use(express.static(path.join(__dirname, "public")));

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "royal_grand_hotel",
  waitForConnections: true, connectionLimit: 10
});
const razorpay = process.env.RAZORPAY_KEY_ID && process.env.RAZORPAY_KEY_SECRET
  ? new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET }) : null;

const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const requireAuth = (req,res,next) => req.session.user ? next() : res.status(401).json({error:"Please log in first."});
const requireAdmin = (req,res,next) => req.session.user?.role === "admin" ? next() : res.status(403).json({error:"Admin access required."});

app.get("/api/health", (req,res) => res.json({status:"ok",service:"Royal Grand Hotel API"}));
app.get("/api/me", (req,res) => res.json({user:req.session.user || null}));
app.get("/api/rooms", asyncRoute(async(req,res) => {
  const [rows] = await pool.query("SELECT * FROM rooms WHERE active=1 ORDER BY price");
  res.json(rows);
}));
app.get("/api/menu", asyncRoute(async(req,res) => {
  const [rows] = await pool.query("SELECT * FROM menu_items WHERE available=1 ORDER BY category");
  res.json(rows);
}));

app.post("/api/register", asyncRoute(async(req,res) => {
  const {name,email,phone,password} = req.body;
  if(!name || !email || !password || password.length < 8) return res.status(400).json({error:"Name, email and password (8+ characters) are required."});
  const hash = await bcrypt.hash(password,12);
  try {
    const [r] = await pool.query("INSERT INTO users(name,email,phone,password_hash) VALUES(?,?,?,?)",[name,email.toLowerCase(),phone || null,hash]);
    req.session.user = {id:r.insertId,name,email:email.toLowerCase(),role:"customer"};
    res.status(201).json({user:req.session.user});
  } catch(e) { if(e.code==="ER_DUP_ENTRY") return res.status(409).json({error:"Email already registered."}); throw e; }
}));
app.post("/api/login", asyncRoute(async(req,res) => {
  const [rows] = await pool.query("SELECT * FROM users WHERE email=?",[String(req.body.email||"").toLowerCase()]);
  if(!rows.length || !(await bcrypt.compare(req.body.password||"",rows[0].password_hash))) return res.status(401).json({error:"Invalid email or password."});
  const u=rows[0]; req.session.user={id:u.id,name:u.name,email:u.email,role:u.role}; res.json({user:req.session.user});
}));
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.post("/api/bookings",requireAuth,asyncRoute(async(req,res)=>{
  const {room_id,check_in,check_out,guests}=req.body;
  const start=new Date(check_in), end=new Date(check_out), now=new Date(); now.setHours(0,0,0,0);
  if(!room_id || isNaN(start) || isNaN(end) || start < now || end <= start) return res.status(400).json({error:"Choose valid future check-in and check-out dates."});
  const nights=Math.ceil((end-start)/86400000);
  const conn=await pool.getConnection();
  try {
    await conn.beginTransaction();
    const [rooms]=await conn.query("SELECT * FROM rooms WHERE id=? AND active=1 FOR UPDATE",[room_id]);
    if(!rooms.length) { await conn.rollback(); return res.status(404).json({error:"Room not found."}); }
    const room=rooms[0], count=Number(guests||1);
    if(count>room.capacity) { await conn.rollback(); return res.status(400).json({error:"Guest count exceeds room capacity."}); }
    const [busy]=await conn.query("SELECT id FROM bookings WHERE room_id=? AND status IN ('pending','confirmed') AND check_in < ? AND check_out > ? FOR UPDATE",[room_id,check_out,check_in]);
    if(busy.length) { await conn.rollback(); return res.status(409).json({error:"This room is unavailable for the selected dates."}); }
    const total=Number(room.price)*nights;
    const code="RGH"+Date.now().toString().slice(-9);
    const [result]=await conn.query("INSERT INTO bookings(booking_code,user_id,room_id,check_in,check_out,guests,nights,total_amount) VALUES(?,?,?,?,?,?,?,?)",[code,req.session.user.id,room_id,check_in,check_out,count,nights,total]);
    await conn.commit();
    res.status(201).json({booking_id:result.insertId,booking_code:code,nights,total_amount:total,status:"pending",message:"Booking created. Complete payment to confirm."});
  } catch(e) { await conn.rollback(); throw e; } finally { conn.release(); }
}));

app.post("/api/payments/order",requireAuth,asyncRoute(async(req,res)=>{
  if(!razorpay) return res.status(503).json({error:"Payment gateway is not configured. Add Razorpay test keys to .env."});
  const [rows]=await pool.query("SELECT * FROM bookings WHERE id=? AND user_id=? AND payment_status='unpaid'",[req.body.booking_id,req.session.user.id]);
  if(!rows.length) return res.status(404).json({error:"Unpaid booking not found."});
  const b=rows[0];
  const order=await razorpay.orders.create({amount:Math.round(Number(b.total_amount)*100),currency:"INR",receipt:b.booking_code});
  await pool.query("UPDATE bookings SET razorpay_order_id=? WHERE id=?",[order.id,b.id]);
  res.json({order_id:order.id,amount:order.amount,currency:order.currency,key_id:process.env.RAZORPAY_KEY_ID,booking_id:b.id});
}));
app.post("/api/payments/verify",requireAuth,asyncRoute(async(req,res)=>{
  const {razorpay_order_id,razorpay_payment_id,razorpay_signature,booking_id}=req.body;
  const [rows]=await pool.query("SELECT * FROM bookings WHERE id=? AND user_id=?",[booking_id,req.session.user.id]);
  if(!rows.length || rows[0].razorpay_order_id!==razorpay_order_id) return res.status(400).json({error:"Booking/order mismatch."});
  const expected=crypto.createHmac("sha256",process.env.RAZORPAY_KEY_SECRET).update(razorpay_order_id+"|"+razorpay_payment_id).digest("hex");
  if(!crypto.timingSafeEqual(Buffer.from(expected),Buffer.from(String(razorpay_signature)))) return res.status(400).json({error:"Payment signature verification failed."});
  await pool.query("UPDATE bookings SET payment_status='paid',status='confirmed',razorpay_payment_id=? WHERE id=?",[razorpay_payment_id,booking_id]);
  res.json({ok:true,message:"Payment verified and booking confirmed."});
}));
app.get("/api/my-bookings",requireAuth,asyncRoute(async(req,res)=>{
  const [rows]=await pool.query("SELECT b.*,r.name AS room_name,r.image_url FROM bookings b JOIN rooms r ON r.id=b.room_id WHERE b.user_id=? ORDER BY b.created_at DESC",[req.session.user.id]); res.json(rows);
}));
app.post("/api/table-reservations",asyncRoute(async(req,res)=>{
  const {name,email,phone,reservation_date,reservation_time,guests,notes}=req.body;
  if(!name||!phone||!reservation_date||!reservation_time||!guests) return res.status(400).json({error:"Please complete all required fields."});
  const [r]=await pool.query("INSERT INTO table_reservations(name,email,phone,reservation_date,reservation_time,guests,notes) VALUES(?,?,?,?,?,?,?)",[name,email||null,phone,reservation_date,reservation_time,guests,notes||null]);
  res.status(201).json({id:r.insertId,message:"Table request received. Our team will confirm shortly."});
}));
app.post("/api/reviews",asyncRoute(async(req,res)=>{
  const {customer_name,rating,comment}=req.body;
  if(!customer_name||!comment||rating<1||rating>5) return res.status(400).json({error:"Enter your name, review and rating."});
  await pool.query("INSERT INTO reviews(customer_name,rating,comment) VALUES(?,?,?)",[customer_name,rating,comment]);
  res.status(201).json({message:"Thank you. Your review will appear after approval."});
}));
app.get("/api/reviews",asyncRoute(async(req,res)=>{
  const [rows]=await pool.query("SELECT customer_name,rating,comment,created_at FROM reviews WHERE approved=1 ORDER BY created_at DESC LIMIT 12"); res.json(rows);
}));

app.get("/api/admin/summary",requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
  const [[bookings]]=await pool.query("SELECT COUNT(*) total_bookings, SUM(status='confirmed') confirmed, SUM(payment_status='paid') paid_count, COALESCE(SUM(CASE WHEN payment_status='paid' THEN total_amount ELSE 0 END),0) revenue FROM bookings");
  const [[rooms]]=await pool.query("SELECT COUNT(*) total_rooms, SUM(active=1) active_rooms FROM rooms");
  const [[customers]]=await pool.query("SELECT COUNT(*) total_customers FROM users WHERE role='customer'");
  res.json({bookings,rooms,customers});
}));
app.get("/api/admin/bookings",requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
  const [rows]=await pool.query("SELECT b.*,u.name customer_name,u.email,r.name room_name FROM bookings b JOIN users u ON u.id=b.user_id JOIN rooms r ON r.id=b.room_id ORDER BY b.created_at DESC"); res.json(rows);
}));
app.patch("/api/admin/bookings/:id",requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
  const status=req.body.status;
  if(!["confirmed","cancelled"].includes(status)) return res.status(400).json({error:"Invalid status."});
  await pool.query("UPDATE bookings SET status=? WHERE id=?",[status,req.params.id]); res.json({ok:true});
}));
app.post("/api/admin/rooms",requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
  const {name,category,description,price,capacity,size_sqm,image_url,amenities}=req.body;
  if(!name||!category||!price) return res.status(400).json({error:"Name, category and price are required."});
  const [r]=await pool.query("INSERT INTO rooms(name,category,description,price,capacity,size_sqm,image_url,amenities) VALUES(?,?,?,?,?,?,?,?)",[name,category,description||"",price,capacity||2,size_sqm||30,image_url||"",amenities||""]);
  res.status(201).json({id:r.insertId});
}));
app.get("/api/admin/reservations",requireAuth,requireAdmin,asyncRoute(async(req,res)=>{
  const [rows]=await pool.query("SELECT * FROM table_reservations ORDER BY reservation_date DESC,reservation_time DESC"); res.json(rows);
}));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"Server error. Check server logs and database configuration."});});
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Royal Grand Hotel running at http://localhost:${port}`));
